<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'sight');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'usbw');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'y#Bv-2B_~>|dy}cVFAV !Fe,j62>wsbFdjlBAsv0dgoR`$v*%U05Kus*4pkGoK&>');
define('SECURE_AUTH_KEY',  '_`,2]l Gd~orFJ: Ta5^ytC24*a8d@~7@QB_,^RXwh;sM.C4|zw:,~#rwC(*U!3e');
define('LOGGED_IN_KEY',    'h]zy}7t7X17[i^[oNVv,_Zm;{zN4^3[gdb?+t<7ja)ej-ba8_#1B:*_?dbHU:qm|');
define('NONCE_KEY',        'D4%*P_WG`[;|Z*h*?={b$t49k6^s-imm#$o2Bib7M|`5qzQ9m^]3AA1k{WWr,x&p');
define('AUTH_SALT',        '*{/sf.(W[,Fk;r?N|HeU#+Cq9yRG9)WRkp6)JwT9jFw#MW[E4=I,/Toxm#!$4iPj');
define('SECURE_AUTH_SALT', '/gB$sw|xVyLWW>m`r5L *LB!*}[K,m{X!.Bwr!^5|TX{0#f{/z$2F*?`~y w&_`3');
define('LOGGED_IN_SALT',   'C,)?mo&O,zbn>RtUXT.2kz1CaV.-f.xBLucL< }u7&)U!N1e]7>z*{m}0]Y)eK@y');
define('NONCE_SALT',       '+z$:d&GVntXu8R4@Ngu*sVFy-8,VO*oQmKo=*|m?P*IeF|y_NU[,o{1+4KDC.6/i');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
